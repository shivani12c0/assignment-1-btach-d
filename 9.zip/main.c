/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int checkPowerofFive(int n);
int main()
{
   int n;
   printf("Enter the number you want to test: ");
   scanf("%d", &n);
   if (checkPowerofFive(n) == 1)
      printf("\n%d is a power of 5\n", n);
   else
      printf("\n%d is not a power of 5\n", n);
   return 0;
}
int checkPowerofFive(int x)
{
   if (x == 0)
      return 0;
   while( x != 1)
   {
      if(x % 5 != 0)
         return 0;
         x /= 5;
   }
   return 1;
}