/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>
int main()
{
    float s,d,h,m;
    scanf("%f",&s);
    d=s/86400;
    h=s/3600;
    m=s/60;
    printf("%.2fD:%.2fH:%.2fM:%2fsec",d,h,m,s);

    return 0;
}